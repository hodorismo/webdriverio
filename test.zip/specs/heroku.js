import File from '../util/file.js';
import moment from 'moment';

const currentEmail = `test_${moment().format('YYYYMMDDHHmm') + '10'}@test.com`;

const contacts = [
    { firstName: 'John', lastName: 'Doe', birthdate: '2000-01-01', email: 'john@example.com', phone: '09123456789', street1: '123 Main St', city: 'Earth', state: 'Isis', postalCode: '3333', country: 'Pelepens' },
    { firstName: 'Jane', lastName: 'Smith', birthdate: '2000-02-02', email: 'jane@example.com', phone: '09123456780', street1: '456 Elm St', city: 'Porgatory', state: 'Barraccuda', postalCode: '2222', country: 'JapanNu' },
    { firstName: 'Converge', lastName: 'ISP', birthdate: '2000-03-03', email: 'converge@example.com', phone: '09123456781', street1: '789 Oak St', city: 'Hell', state: 'Deadlalala', postalCode: '1111', country: 'Pilipins' },
];

describe('Heroku App', () => {
    it('Heroku App SignUp_TC001', async () => {
        await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
        await $('//button[@id="signup"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="signup"]').click();
        
        await $('//input[@id="firstName"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="firstName"]').setValue('Test User');
        await $('//input[@id="lastName"]').setValue('Example');
        await $('//input[@id="email"]').setValue(currentEmail);
        await $('//input[@id="password"]').setValue('testing');
        
        await $('//button[@id="submit"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="submit"]').click();
        
        await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
    });

    it('Heroku App Login User_TC002', async () => {
        await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
        
        await $('//input[@id="email"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="email"]').setValue(currentEmail);
        
        await $('//input[@id="password"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="password"]').setValue('testing');
        
        await $('//button[@id="submit"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="submit"]').click();
    });

    it('Heroku App Add Contacts TC003', async () => {
        for (const contact of contacts) {
            await $('//button[@id="add-contact"]').waitForDisplayed({ timeout: 10000 });
            await $('//button[@id="add-contact"]').click();
            
            await $('//input[@id="firstName"]').waitForDisplayed({ timeout: 10000 });
            await $('//input[@id="firstName"]').setValue(contact.firstName);
            await $('//input[@id="lastName"]').setValue(contact.lastName);
            await $('//input[@id="birthdate"]').setValue(contact.birthdate);
            await $('//input[@id="email"]').setValue(contact.email);
            await $('//input[@id="phone"]').setValue(contact.phone);
            await $('//input[@id="street1"]').setValue(contact.street1);
            await $('//input[@id="city"]').setValue(contact.city);
            await $('//input[@id="stateProvince"]').setValue(contact.state);
            await $('//input[@id="postalCode"]').setValue(contact.postalCode);
            await $('//input[@id="country"]').setValue(contact.country);
            
            await $('//button[@id="submit"]').waitForDisplayed({ timeout: 10000 });
            await $('//button[@id="submit"]').click();
        }
        await $('//button[@id="add-contact"]').waitForDisplayed({ timeout: 10000 });
    });

    it('Heroku App Edit Contact TC004', async () => {
        await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
        await $('//input[@id="email"]').waitForDisplayed({ timeout: 20000 });
        await $('//input[@id="email"]').setValue(currentEmail);
        
        await $('//input[@id="password"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="password"]').setValue('testing');
        
        await $('//button[@id="submit"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="submit"]').click();
        
        await $('/html/body/div/div/table/tr[1]/td[2]').click();
        await $('//button[@id="edit-contact"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="edit-contact"]').click();
        
        await $('//input[@id="postalCode"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="postalCode"]').clearValue();
        await $('//input[@id="postalCode"]').setValue('1234');
        
        await $('//button[@id="submit"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="submit"]').click();
        
        await $('//button[@id="return"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="return"]').click();
    });

    it('Heroku App Delete Contact TC005', async () => {
        await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
        await $('//input[@id="email"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="email"]').setValue(currentEmail);
        
        await $('//input[@id="password"]').waitForDisplayed({ timeout: 10000 });
        await $('//input[@id="password"]').setValue('testing');
        
        await $('//button[@id="submit"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="submit"]').click();
        
        await $('/html/body/div/div/table/tr[1]/td[2]').click();
        await $('//button[@id="delete"]').waitForDisplayed({ timeout: 10000 });
        await $('//button[@id="delete"]').click();
        await browser.acceptAlert();

    });

    it('Heroku App Export Contacts on File_TC006', async () => {
        await browser.url('https://thinking-tester-contact-list.herokuapp.com/');
        
        await $('//input[@id="email"]').waitForDisplayed({ timeout: 20000 });
        await $('//input[@id="email"]').setValue(currentEmail);
        
        await $('//input[@id="password"]').waitForDisplayed({ timeout: 20000 });
        await $('//input[@id="password"]').setValue('testing');
        
        await $('//button[@id="submit"]').waitForDisplayed({ timeout: 20000 });
        await $('//button[@id="submit"]').click();

        const table = await $('table');
        const rows = await table.$$(`tr`);
        const userCount = await rows.length;
        const contactData = {};
        for (let i = 1; i < userCount; i++) {
            const cells = await rows[i].$$(`td`);
            

            for (let j = 2; j < cells.length +1; j++) {
                const header = await $(`//thead//tr//th[${j - 1}]`).getText();
                const data = await cells[j].getText();
                contactData[header] = data;
            }
            await File.appendTxtFile(global.strPathContacts, JSON.stringify(contactData, null, 2));
        }
        await expect($('//button[@id="add-contact"]')).toBeDisplayed({ timeout: 20000 });
    });
    
});
