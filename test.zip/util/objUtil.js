
import File from '../util/file.js' 
 
 class objUtil {

    /***********************************************
     * @function clickObject | @author aira_20241023
     * @description Click Object
     * @param {Object} objElement - Object to be clicked
     * @returns <none>
     ***********************************************/

    async clickObject(objElement) {
        await File.appendTxtFile(global.strPath,'Started Function: clickObject');
        await objElement.waitForExist();
        await objElement.click();
        const strXpath = await objElement.selector;
        await File.appendTxtFile(global.strPath, `Completed Function: clickObjects - Successfuly clicked [${strXpath}]`);
    }

    /** 
     * * @function setValue | @author aibautista_20241023
     * @description Click Object
     * @param {Object} objElement 
     * @param {String} strText 
     */
    async setObjectValue(objElement, strText){
        await File.appendTxtFile(global.strPath,'Started Function: setObjectValue');
        await objElement.waitForExist();
        await objElement.setValue(strText);
        const strXpath = await objElement.selector;
        await File.appendTxtFile(global.strPath, `Completed Function: setObjectValue - Successfuly clicked [${strXpath}]`);
    }

    async getObjText(objElement){
        await File.appendTxtFile(global.strPath, 'Started Function: getObjText');
        await objElement.waitForExist();
        const strText = objElement.getText();
        const strXpath = await objElement.selector;
        await File.appendTxtFile(global.strPath, `Completed Function: getObjText - Successfuly clicked [${strXpath}]`);
        return strText;
    }

    async getObjValue(objElement){
        await File.appendTxtFile(global.strPath, 'Started Function: getObjValue');
        await objElement.waitForExist();
        const strText = objElement.getText();
        const strXpath = await objElement.selector;
        await File.appendTxtFile(global.strPath, `Completed Function: getObjValue - Successfuly clicked [${strXpath}]`);
        return strText;
    }

}

export default new objUtil();